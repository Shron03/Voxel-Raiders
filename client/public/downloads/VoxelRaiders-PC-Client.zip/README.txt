================================================
VOXEL RAIDERS: DIMENSIONAL RIFT - PC CLIENT
================================================
How to play:
1. Double-click "Start-Game-PC.bat"
2. The game will launch your local client and open automatically in your browser.
3. You can join online games with room codes, or discover games hosted on your local Wi-Fi / LAN network.
