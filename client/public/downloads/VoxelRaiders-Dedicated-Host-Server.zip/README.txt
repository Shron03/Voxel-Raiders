================================================
VOXEL RAIDERS - DEDICATED HOST SERVER (PC)
================================================
How to host a dedicated multiplayer session:
1. Double click "Start-Host-Server.bat"
2. The server will start on port 10000 and broadcast a LAN beacon on UDP port 48888.
3. Friends on the same Wi-Fi can join instantly via the "LAN & LOCAL" tab in the game.
4. Auto-saves and world saves are persisted locally at:
   %APPDATA%\VoxelRaiders\saves\
